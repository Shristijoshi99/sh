from .list1 import *
from .set2 import *
from .dict3 import *