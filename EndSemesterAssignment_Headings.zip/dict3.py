def len3(d):
    return len(d)

def add3(k, v):
    d = {}
    d[k] = v
    return d

def keys3():
    d = {'a': 1, 'b': 2}
    return list(d.keys())

def values3():
    d = {'a': 1, 'b': 2}
    return list(d.values())