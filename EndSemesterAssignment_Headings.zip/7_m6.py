# 7. m6.py - Uses my_package with __init__.py

from my_package import *

print(append1(7))
print(extend1([1, 2]))
print(pop())
print(remove1(2))

print(slen2({1, 2}))
print(adds2(4))
print(remove2(4))

print(len3({'a': 10}))
print(add3('b', 20))
print(keys3())
print(values3())