# 8. __init__.py - Initializes package modules

from .list1 import *
from .set2 import *
from .dict3 import *