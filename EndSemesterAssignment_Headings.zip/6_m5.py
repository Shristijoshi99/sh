# 6. m5.py - Uses cal1.py

import cal1

print("Addition:", cal1.add1(5, 3))
print("Subtraction:", cal1.sub1(10, 4))
print("Multiplication:", cal1.mul1(2, 8))
print("Division:", cal1.div1(20, 5))
print("Modulo:", cal1.mod1(10, 3))
print("Power:", cal1.pow1(2, 4))