def add1(x, y):
    return x + y

def sub1(x, y):
    return x - y

def mul1(x, y):
    return x * y

def div1(x, y):
    return x / y if y != 0 else "Cannot divide by zero"

def mod1(x, y):
    return x % y

def pow1(x, y):
    return x ** y